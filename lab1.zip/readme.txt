Lab1:

make has created make.o (object) which has been converted to lab1.hex and flashed to my arduino with Avrdude.
Tested program using Putty (Com4, 38400) typing ON and OFF to light and switch off led, other characters are ignored.
